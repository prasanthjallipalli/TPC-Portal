
<html>
    <body>
        <h1> TPC Login Page</h1>
        <br><br><br>
        <form action="tpc_login_verify.php" method="post">
            ID: <input type="text" name="id"><br>
            Password: <input type="password" name="password"><br>
        <input type="submit", value="Login">
        </form>
    </body>
</html>